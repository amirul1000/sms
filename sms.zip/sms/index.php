<?php
   Header("Location:login.php");
?>