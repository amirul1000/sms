<?php
        session_start();
       include("common/lib.php");
	    include("lib/class.db.php");
	    include("common/config.php");
				  
		$info["table"] = "phone";
		$info["fields"] = array("phone.*"); 
		$info["where"]   = "1 AND  booked_till_date<'".date("Y-m-d")."' AND status='booked'";
		$arr =  $db->select($info);
		
		for($i=0;$i<count($arr);$i++)
		{
			
			  $Id = $arr[$i]['id'];
           $phone_no = $arr[$i]['phone_no'];
           
           echo "Executing $phone_no <br>"; 			
			
			     unset($info);
			     unset($data);
        	 $info['table']    = "phone";
        	 $data['booked_till_date']   = '';
          $data['status']   = 'free';
		    $info['data']     =  $data;
			 $info['where'] = "id=".$Id;
			   $db->update($info);

             
              unset($info);
			     unset($data);
           $info['table']    = "phonesold";
           $data['status']   = 'inactive';
			  $info['data']     =  $data;
			  $info['where'] = "phone_id=".$Id;
					$db->update($info);
      }
?>