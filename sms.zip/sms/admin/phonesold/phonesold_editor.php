<?php
 include("../template/header.php");
?>
 <a href="index.php?cmd=edit" class="btn green">Add a phonesold</a> <br><br>
     <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption"><i class="fa fa-globe"></i><b><?=ucwords(str_replace("_"," ","phonesold"))?></b>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="reload"></a>
                    <a href="javascript:;" class="remove"></a>
                </div>
            </div>             
            <div class="portlet-body">
	         <div class="table-responsive">	
                <table class="table">
 <tr>
  <td>  

	 <form name="frm_index" method="post"  enctype="multipart/form-data" onSubmit="return checkRequired();">			
		<div class="portlet-body">
	         <div class="table-responsive">	
                <table class="table">
		 <tr>
							 <td>Users</td>
							 <td><?php
	$info['table']    = "users";
	$info['fields']   = array("*");   	   
	$info['where']    =  "1=1 ORDER BY id DESC";
	$resusers  =  $db->select($info);
?>
<select  name="users_id" id="users_id"   class="textbox">
	<option value="">--Select--</option>
	<?php
	   foreach($resusers as $key=>$each)
	   { 
	?>
	  <option value="<?=$resusers[$key]['id']?>" <?php if($resusers[$key]['id']==$users_id){ echo "selected"; }?>><?=$resusers[$key]['first_name']?></option>
	<?php
	 }
	?> 
</select></td>
					  </tr><tr>
							 <td>Phone</td>
							 <td><?php
	$info['table']    = "phone";
	$info['fields']   = array("*");   	   
	$info['where']    =  "1=1 ORDER BY id DESC";
	$resphone  =  $db->select($info);
?>
<select  name="phone_id" id="phone_id"   class="textbox">
	<option value="">--Select--</option>
	<?php
	   foreach($resphone as $key=>$each)
	   { 
	?>
	  <option value="<?=$resphone[$key]['id']?>" <?php if($resphone[$key]['id']==$phone_id){ echo "selected"; }?>><?=$resphone[$key]['phone_no']?></option>
	<?php
	 }
	?> 
</select></td>
					  </tr><tr>
						 <td>Start Date</td>
						 <td>
						    <input type="text" name="start_date" id="start_date"  value="<?=$start_date?>" class="textbox">
							<a href="javascript:void(0);" onclick="displayDatePicker('start_date');"><img src="../../images/calendar.gif" width="16" height="16" border="0" /></a>
						 </td>
				     </tr><tr>
						 <td>End Date</td>
						 <td>
						    <input type="text" name="end_date" id="end_date"  value="<?=$end_date?>" class="textbox">
							<a href="javascript:void(0);" onclick="displayDatePicker('end_date');"><img src="../../images/calendar.gif" width="16" height="16" border="0" /></a>
						 </td>
				     </tr><tr>
		           		 <td>Status</td>
				   		 <td><?php
	$enumindex = getEnumFieldValues('phonesold','status');
?>
<select  name="status" id="status"   class="textbox">
<?php
   foreach($enumindex as $key=>$value)
   { 
?>
  <option value="<?=$value?>" <?php if($value==$status){ echo "selected"; }?>><?=$value?></option>
 <?php
  }
?> 
</select></td>
				  </tr>
		 <tr> 
			 <td align="right"></td>
			 <td>
				<input type="hidden" name="cmd" value="add">
				<input type="hidden" name="id" value="<?=$Id?>">			
				<input type="submit" name="btn_submit" id="btn_submit" value="submit" class="button_blue">
			 </td>     
		 </tr>
		</table>
		</div>
		</div>
	</form>
  </td>
 </tr>
</table>
</div>
</div>
<?php
 include("../template/footer.php");
?>

