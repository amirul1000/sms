<?php
 include("../template/header.php");
?>
    <a href="index.php?cmd=list" class="btn green">List</a> <br><br>
     <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption"><i class="fa fa-globe"></i><b><?=ucwords(str_replace("_"," ","Phone"))?></b>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="reload"></a>
                    <a href="javascript:;" class="remove"></a>
                </div>
            </div>             
            <div class="portlet-body">
	         <div class="table-responsive">	
                <table class="table">
						 <tr>
						  <td>  
							 <form name="frm_phone" method="post"  enctype="multipart/form-data" onSubmit="return checkRequired();">			
								 <div class="portlet-body">
							         <div class="table-responsive">	
						                <table class="table">
												 <tr>
																	 <td>Country</td>
																	 <td><?php
											$info['table']    = "country";
											$info['fields']   = array("*");   	   
											$info['where']    =  "1=1 ORDER BY id DESC";
											$rescountry  =  $db->select($info);
										?>
										<select  name="country_id" id="country_id"   class="textbox">
											<option value="">--Select--</option>
											<?php
											   foreach($rescountry as $key=>$each)
											   { 
											?>
											  <option value="<?=$rescountry[$key]['id']?>" <?php if($rescountry[$key]['id']==$country_id){ echo "selected"; }?>><?=$rescountry[$key]['country']?></option>
											<?php
											 }
											?> 
										</select></td>
															  </tr><tr>
																 <td>Phone No</td>
																 <td>
																    <input type="text" name="phone_no" id="phone_no"  value="<?=$phone_no?>" class="textbox">
																 </td>
														     </tr><tr>
												           		 <td>Status</td>
														   		 <td><?php
											$enumphone = getEnumFieldValues('phone','status');
										?>
										<select  name="status" id="status"   class="textbox">
										<?php
										   foreach($enumphone as $key=>$value)
										   { 
										?>
										  <option value="<?=$value?>" <?php if($value==$status){ echo "selected"; }?>><?=$value?></option>
										 <?php
										  }
										?> 
										</select></td>
														  </tr>
									 <tr> 
										 <td align="right"></td>
										 <td>
											<input type="hidden" name="cmd" value="add">
											<input type="hidden" name="id" value="<?=$Id?>">			
											<input type="submit" name="btn_submit" id="btn_submit" value="submit" class="button_blue">
										 </td>     
									 </tr>
									</table>
						</div>
						</div>
					</form>
				  </td>
				 </tr>
			</table>
		</div>
	</div>
<?php
 include("../template/footer.php");
?>

