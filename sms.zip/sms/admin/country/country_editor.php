<?php
 include("../template/header.php");
?>
       <a href="index.php?cmd=list" class="btn green">List</a> <br><br>
       <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption"><i class="fa fa-globe"></i><b><?=ucwords(str_replace("_"," ","country"))?></b>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="reload"></a>
                    <a href="javascript:;" class="remove"></a>
                </div>
            </div>             
            <div class="portlet-body">
	         <div class="table-responsive">	
                <table class="table">
						 <tr>
						  <td>  

							 <form name="frm_country" method="post"  enctype="multipart/form-data" onSubmit="return checkRequired();">			
								<table cellspacing="3" cellpadding="3" border="0" align="center" class="bodytext" width="100%">  
								 <tr>
									 <td>Country</td>
									 <td>
									    <input type="text" name="country" id="country"  value="<?=$country?>" class="textbox">
									 </td>
							    </tr>
							    <tr>
				           		 <td>Status</td>
						   		 <td>
						   		   <?php
											$enumphone = getEnumFieldValues('country','status');
										?>
										<select  name="status" id="status"   class="textbox">
										<?php
										   foreach($enumphone as $key=>$value)
										   { 
										?>
										  <option value="<?=$value?>" <?php if($value==$status){ echo "selected"; }?>><?=$value?></option>
										 <?php
										  }
										?> 
										</select>
										</td>
								 </tr>
								 <tr> 
									 <td align="right"></td>
									 <td>
										<input type="hidden" name="cmd" value="add">
										<input type="hidden" name="id" value="<?=$Id?>">			
										<input type="submit" name="btn_submit" id="btn_submit" value="submit" class="button_blue">
									 </td>     
								 </tr>
								</table>
							</form>
						  </td>
						 </tr>
						</table>
						</div>
              </div>
         </div>     
<?php
 include("../template/footer.php");
?>

