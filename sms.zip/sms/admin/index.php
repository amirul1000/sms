<?php
     
	   Header("Location: login/");
?>