<?php
  include("../template/header.php");
?>   
    
        <!-- BEGIN PAGE TITLE & BREADCRUMB-->
        <h3 class="page-title">
            Home
        </h3>
        
        <div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<div class="dashboard-stat blue-madison">
						
                        
                        
                        
					</div>
				</div>
          </div>      
<?php
  include("../template/footer.php");
?>					               
