<?php
   
   
   include("zensend_php_api-1.0.3/init.php");
   
   $client = new ZenSend\Client("9Z4bUDS13a4fVX50snGV8g");

	$request = new ZenSend\SmsRequest();
	$request->body = "Welcome to spin";
	$request->originator = "SPINTOWIN";
	$request->numbers = ["00447860039293"];

	$result = $client->send_sms($request);
   
   echo "<pre>";
   print_r($result);
   echo "</pre>";

?>