<?php
 include("template/header.php");
?>
<?php
   if(isset($message))
   {
     echo  $message."<br>";   
   }
?>
<a href="manage_phone.php" class="btn green">List</a> <br><br>
<script type="text/javascript" >
			function fillUpPhone(country_id)
			{
			    objselect = document.getElementById("phone_no");
			    objselect.options.length = 0;
			    $("#spinner2").html('<img src="images/indicator.gif" alt="Wait" />');
			    $.ajax({  
			      url: 'buy_new_phone.php?cmd=phone&country_id='+country_id,
			      success: function(data) {
			              var obj = eval(data);    
			              
			              objselect.add(new Option('--select--',''), null);
			              for(var i=0;i<obj.length;i++)
			              {
			                 text = obj[i].phone_no;
			                 objselect.add(new Option(text,obj[i].id), null);
			              }
			            $("#spinner2").html('');
			          }
			        });
			}
</script>

     <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption"><i class="fa fa-globe"></i><b><?=ucwords(str_replace("_"," ","Phone"))?></b>
                </div>
                <div class="tools">
                    <a href="javascript:;" class="reload"></a>
                    <a href="javascript:;" class="remove"></a>
                </div>
            </div>             
            <div class="portlet-body">
	         <div class="table-responsive">	
                <table class="table">
						 <tr>
						  <td>  

							 <form name="frm_phone" method="post"  enctype="multipart/form-data" onSubmit="return checkRequired();">			
								 <div class="portlet-body">
							         <div class="table-responsive">	
						                <table class="table">
												 <tr>
																	 <td>Country</td>
																	 <td>
																<div id="spinner2"></div>	
																 
																	 <?php
											$info['table']    = "country";
											$info['fields']   = array("*");   	   
											$info['where']    =  "1=1 AND status='active' ORDER BY country ASC";
											$rescountry  =  $db->select($info);
										?>
										<select  name="country_id" id="country_id"   class="textbox" onChange="fillUpPhone(this.value)">
											<option value="">--Select--</option>
											<?php
											   foreach($rescountry as $key=>$each)
											   { 
											?>
											  <option value="<?=$rescountry[$key]['id']?>" <?php if($rescountry[$key]['id']==$country_id){ echo "selected"; }?>><?=$rescountry[$key]['country']?></option>
											<?php
											 }
											?> 
										</select></td>
															  </tr><tr>
																 <td>Phone No</td>
																 <td>
																    <select type="text" name="phone_no" id="phone_no"  class="textbox" required>
																    </select>
																 </td>
														     </tr>
									 <tr> 
										 <td align="right"></td>
										 <td>
											<input type="hidden" name="cmd" value="add">
											<input type="hidden" name="id" value="<?=$Id?>">			
											<input type="submit" name="btn_submit" id="btn_submit" value="submit" class="button_blue">
										 </td>     
									 </tr>
									</table>
						</div>
						</div>
					</form>
				  </td>
				 </tr>
			</table>
		</div>
	</div>
<?php
 include("template/footer.php");
?>

