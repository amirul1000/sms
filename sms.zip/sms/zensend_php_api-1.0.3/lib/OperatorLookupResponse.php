<?php
namespace ZenSend;

class OperatorLookupResponse
{
  public $mnc;
  public $mcc;
  public $operator;
  public $cost_in_pence;
  public $new_balance_in_pence;
}

?>
