<?php
  function add_credit($db,$amount)
   {
	    $info['table']    = "balance";
	  	 $data['users_id']   = $_SESSION['users_id'];
	    $data['credit']   = amount;
	    //$data['debit']   = $_REQUEST['debit'];
	    //$data['pay_by']   = $_REQUEST['pay_by'];
	    //$data['description']   = $_REQUEST['description'];
	    $data['date_time']   = date("Y-m-d");
		  $info['data']     =  $data;			
				 $db->insert($info);
    }
  
  function add_debit($db,$amount)
   {
	    $info['table']    = "balance";
	  	 $data['users_id']   = $_SESSION['users_id'];
	    //$data['credit']   = amount;
	    $data['debit']   = $amount;
	    $data['pay_by']   = 'deposit';
	    //$data['description']   = $_REQUEST['description'];
	    $data['date_time']   = date("Y-m-d");
		 $info['data']     =  $data;			
				 $db->insert($info);
    }
    
    function check_balance($db)
    {       
       $info['table']    = "balance";
       $info["fields"]  = array("sum(credit) as credit,sum(debit) as debit"); 
		 $info['where']     =  "users_id='".$_SESSION['users_id']."'";
		 $arr = $db->select($info);
		 
		 $balance = $arr[0]['credit']-$arr[0]['debit'];		 
	    
	     return $balance; 			 
    }


?>