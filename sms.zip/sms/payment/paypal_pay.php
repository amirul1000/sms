<?php
$total  = $_SESSION['total'];
$total = number_format($total,2);
?>
<form method="post" action="https://www.sandbox.paypal.com/cgi-bin/webscr"> <!--https://www.paypal.com/cgi-bin/webscr-->
	<input class="wp_cart_checkout_button" type="image"
		alt="Make payments with PayPal - it's fast, free and secure!"
		name="submit" src="images/btn_xpressCheckout.gif"> <input
		type="hidden" value="amirrucst-faciliator@gmail.com" name="business"> <input
		type="hidden" value="2" name="rm"> <input type="hidden"
		value="Buy Virtual Phone" name="on0_1"> <input type="hidden" value=""
		name="on1_1"> <input type="hidden" value="1" name="item_name_1"> <input
		type="hidden" value=""
		name="item_number_1"> <input type="hidden" value="<?=$total?>"
		name="amount_1"> <input type="hidden" value="1" name="quantity_1"> <input
		type="hidden" value="0" name="tax_1"> <input type="hidden" value="0"
		name="shipping_1"> <input type="hidden" value="USD"
		name="currency_code"> <input type="hidden" value="_cart" name="cmd"> <input
		type="hidden" value="1" name="upload"> <input type="hidden"
		value="3FWGC6LFTMTUG" name="mrb"> <input type="hidden"
		value="http://vps49691.dedimax.com/payment/paypal_success.php" name="return"> <input
		type="hidden" value="http://vps49691.dedimax.com/fill_credit.php" name="shopping_url">
	<input type="hidden"
		value="http://vps49691.dedimax.com/payment/paypal_notify.php" name="notify_url">
</form>
