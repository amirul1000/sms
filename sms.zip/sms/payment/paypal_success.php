<?php
       session_start();
       include("../common/lib.php");
	   include("../lib/class.db.php");
	   include("../common/config.php");

?>
<?php
 
?>
<div class="content_block">

	<br /> <br /> <br />
	<fieldset>
		<legend>
			<h3>Success</h3>
		</legend>
		<center>
			Payment Success | Thank you<br />
			<a href="../fill_credit.php">Back</a>
			<?php   
			
			      unset($info);
				   unset($data);
			   $info["table"] = "balance";
				$info["fields"] = array("*"); 
				$info["where"]   = "1  AND txn_id='".$_POST['txn_id']."'";
				$arr =  $db->select($info);
			
			if($_POST['payment_status'] == 'Completed' || $_POST['payment_status'] == 'Pending' && empty($arr[0]['txn_id']))
			{
					     unset($info);
						  unset($data);
			       $info['table']    = "balance";
				    $data['users_id']   = $_SESSION['users_id'];
				    $data['txn_id']     = $_POST['txn_id'];
                $data['description']   = "Deposit Payment Advance";
                $data['date_time']   = date("Y-m-d H:i:s");
                $data['credit']   =  $_SESSION['total'];
                $data['debit']   = 0;
                $data['pay_by']  = 'paypal';
				    $info['data']     =  $data;
				     $db->insert($info);
				     
				     unset($_POST);
				     
				   sendemail($db);
			}
		    /*
			 * get Balance
			*/
		    function getBalance($db)
			{
			      unset($info);
				   unset($data);
			   $info["table"] = "balance";
				$info["fields"] = array("sum(credit-debit) as balance"); 
				$info["where"]   = "1  AND users_id='".$_SESSION['users_id']."'";
				$arr =  $db->select($info);
				
				return $arr[0]["balance"];
			}
			/*
			*send email
			*/
			function sendemail($db)
			{
				$message = "";
				// Always set content-type when sending HTML email
			   $headers = "MIME-Version: 1.0" . "\r\n";
			   $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
			  // More headers
			   $headers .= 'From: http://vps49691.dedimax.com/<amirrucst@gmail.com>' . "\r\n";
			   $headers .= 'Reply-To: amirrucst@gmail.com' . "\r\n";
			   $headers .= 'Return-Path: amirrucst@gmail.com' . "\r\n";
		  	   mail($_SESSION["email"],$subject,$message, $headers);
			}
			
			?>
	
	</fieldset>
</div>

<?php

?>