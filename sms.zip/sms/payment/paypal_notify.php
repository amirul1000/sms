<?php
session_start();
include("../common/lib.php");
include("../lib/class.db.php");
include("../common/config.php");
?>
<div class="content_block">
	<fieldset>
		<legend>
			<h3>Fail</h3>
		</legend>
		<?php
		sendemail($db);
		function sendemail($db)
		{
			$subject = json_decode($_REQUEST); 
			$message = json_decode($_REQUEST); 
			// Always set content-type when sending HTML email
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
			// More headers
			$headers .= 'From: Moturjem Translation<amirrucst@gmail.com>' . "\r\n";
			$headers .= 'Reply-To: amirrucst@gmail.com' . "\r\n";
			$headers .= 'Return-Path: amirrucst@gmail.com' . "\r\n";
		
			mail($_SESSION["email"],$subject,$message, $headers);			
		}

		?>
		<br /> <br /> <br />
		<center>
			<font color='#FF0000'>Payment Failed</font>
	
	</fieldset>
</div>
