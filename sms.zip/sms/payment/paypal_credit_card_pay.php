<?php
     if($total>0)
	 {	
	   $server_url  =  "https://api-3t.paypal.com/nvp";
	   
	   $a['USER'] = "0placemarket_api1.gmail.com";
	   $a['PWD'] = "2U9VAEDYVU5EWA57";
	   $a['SIGNATURE'] = "AQT15IRKq0fLck263XGKNzdKQQL-A6cduTEJ2Qa1VVTIQtinqeLJqm3J";
	   $a['VERSION'] = "97.0";
	   $a['PAYMENTREQUEST_0_PAYMENTACTION'] = "Sale";
	   $a['PAYMENTREQUEST_0_AMT'] = $total;
	   $a['RETURNURL'] = "http://www.0place.com/ad/advertiser/payment/paypal_success";
	   $a['CANCELURL'] = "http://www.0place.com/ad/advertiser/adbalance/adbalance?cmd=list";
	   $a['METHOD']    ="SetExpressCheckout";
	   
	   
	   //post to t3 as string URL
		$postValuesString = ""; // blank to start
				
		foreach($a as $var => $val){
			if(strlen($postValuesString))$postValuesString.= "&";
			$postValuesString.= $var . "=" . urlencode($val);        
		}   
		// cURL t3
		$ch = curl_init();
		
		curl_setopt(    $ch,    CURLOPT_URL,               $server_url              );
		curl_setopt(    $ch,    CURLOPT_POST,              0                        );
		curl_setopt(    $ch,    CURLOPT_POSTFIELDS,        $postValuesString        );    
		curl_setopt(    $ch,    CURLOPT_HTTPHEADER,        array("Expect:")         ); 
		curl_setopt(    $ch,    CURLOPT_FAILONERROR,       1                        );
		curl_setopt(    $ch,    CURLOPT_HEADER,            0                        );
		curl_setopt(    $ch,    CURLOPT_RETURNTRANSFER,    1                        );
		curl_setopt(    $ch,    CURLOPT_SSL_VERIFYPEER,    false                    );
		curl_setopt(    $ch,    CURLOPT_SSL_VERIFYHOST,    false                    );
		curl_setopt(    $ch,    CURLOPT_TIMEOUT,           120                      );
		curl_setopt(    $ch,    CURLINFO_HEADER_OUT,       true                     );
		curl_setopt(    $ch,    CURLOPT_HTTP_VERSION,      CURL_HTTP_VERSION_1_1    );
		
		if(curl_errno($ch)){              
			echo "100: ".$error_message;
			$t3_curl_status = "ERROR: cURL t3";
		}
		else {
			// successful send to t3
			$Response = curl_exec($ch);
			$t3_curl_status = "SUCCESS: T3 send";
			curl_close($ch);
			$arrStr = explode("&",$Response);
			$token = str_replace("TOKEN=","",$arrStr[0]);
		}
      }
?>
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=<?=$token?>">
           <img src="https://www.paypal.com/en_US/i/logo/PayPal_mark_37x23.gif" align="left" style="margin-right:7px;">
                <span style="font-size:11px; font-family: Arial, Verdana;">ExpressCheckout</span>
</a>
