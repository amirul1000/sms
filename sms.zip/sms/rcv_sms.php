<?php
       session_start();
       include("common/lib.php");
	    include("lib/class.db.php");
	    include("common/config.php");
	    
	     	unset($info);
			unset($data); 
	   $info["table"] = "phonesold left outer join phone ON(phonesold.phone_id=phone.id)";
		$info["fields"] = array("phonesold.*"); 
		$info["where"]   = "1   AND phone.phone_no LIKE '%".$_REQUEST['DESTINATION']."%' AND  phonesold.end_date>'".date("Y-m-d")."' AND  phonesold.status='active'";
		$arr =  $db->select($info);
		$users_id = $arr[0]['users_id'];
	  
        	unset($info);
			unset($data); 
		 $info['table']    = "receivesms";
		 $data['users_id']   = $users_id;
		 $data['BODY']   = $_REQUEST['BODY'];
       $data['MONUMBER']   = $_REQUEST['MONUMBER'];
       $data['DESTINATION']   = $_REQUEST['DESTINATION'];
       $data['RECEIVETIME']   = $_REQUEST['RECEIVETIME'];
       $data['GUID']   = $_REQUEST['GUID'];
		 $data['date_time']   = date("Y-m-d H:i:s");
		 $info['data']     =  $data;
				 $db->insert($info);
				 
				 
		if($users_id>0)
		{
				unset($info);
				unset($data); 
		 $info['table']    = "balance";
	  	 $data['users_id']   = $users_id;
	    //$data['credit']   = amount;
	    $data['debit']   = "0.10";
	    $data['pay_by']   = "deposit";
	    $data['description']   = "received sms";
	    $data['date_time']   = date("Y-m-d");
		 $info['data']     =  $data;			
				 $db->insert($info);
		}		
?>	