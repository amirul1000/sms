<?php 

   $host     = "localhost"; 
   $database = "sms";
   $user     = "root";
   $password = "secret";

  /* $host     = "localhost"; 
   $database = "contractor_tracker";
   $user     = "contractor_track";
   $password = "Cabins44+";*/
   
   
   $db  = new Db($host,$user,$password,$database);

?>
