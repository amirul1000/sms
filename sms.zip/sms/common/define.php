<?php

   define('DATABASE',"contractor_tracker");


?>