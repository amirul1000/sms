<?php
       session_start();
       include("common/lib.php");
	   include("lib/class.db.php");
	   include("common/config.php");
	   include("lib.php");
	   
	     
	     if(empty($_SESSION['users_id'])) 
	   {
	     Header("Location: login.php");
	   }
	  
	   $cmd = $_REQUEST['cmd'];
	   switch($cmd)
	   {
	     
		  case 'add':
		        $balance = check_balance($db); 
		        if($balance>0.60 && $_REQUEST['phone_no']>0)
		        {
				 	 $info['table']      = "phonesold";
				    $data['users_id']   = $_SESSION['users_id'];
	             $data['phone_id']   = $_REQUEST['phone_no'];
	             $data['buy_price']  = '0.60';
	             $data['start_date'] = date("Y-m-d H:i:s");
	             $data['end_date']   =  date('Y-m-d', strtotime("+30 days"));
				 	 $data['status']   = 'active';
				 	 $info['data']       =  $data;
					
					if(empty($_REQUEST['id']))
					{
						 $db->insert($info);
					}
					else
					{
						$Id            = $_REQUEST['id'];
						$info['where'] = "id=".$Id;						
						$db->update($info);
					}
					
					$amount = '0.60';
					add_debit($db,$amount);
					$message = "Your phone is listed successfully from ".date("Y-m-d ")." to ".date('Y-m-d', strtotime("+30 days"));
					
					///////////////////////update phone//////////////////////
					  unset($info);
					  unset($data);
					 $info['table']    = "phone";
		          $data['booked_till_date'] =  date('Y-m-d', strtotime("+30 days"));
		          $data['status']   = 'booked'; 
		          $info['data']       =  $data;
		          $info['where'] = "id=".$_REQUEST['phone_no'];
						$db->update($info);
					///////////////////////////////////////////////////
				}
				else {
					   $message = "Error:Your balance is less than 0.60";
					}
				include("buy_new_phone_editor.php");						   
				break; 
			case "phone":
					$info["table"] = "phone";
					$info["fields"] = array("phone.*"); 
					$info["where"]   = "1  AND country_id='".$_REQUEST['country_id']."' AND status!='booked'";
					$arr =  $db->select($info);
					echo json_encode($arr);			
			    break;					
			    
		    /*case "edit":      
					$Id               = $_REQUEST['id'];
					if( !empty($Id ))
					{
						$info['table']    = "phone";
						$info['fields']   = array("*");   	   
						$info['where']    =  "id=".$Id;
					   
						$res  =  $db->select($info);
					   
						$Id        = $res[0]['id'];  
						$country_id    = $res[0]['country_id'];
						$phone_no    = $res[0]['phone_no'];
						$status    = $res[0]['status'];
						
					 }
							   
					include("buy_new_phone_editor.php");						  
					break;
							   
         case "delete": 
					$Id               = $_REQUEST['id'];
					
					$info['table']    = "phone";
					$info['where']    = "id='$Id'";
					
					if($Id)
					{
						$db->delete($info);
					}
					include("buy_new_phone_list.php");						   
					break; */
						   
         case "list" :    	 
				  if(!empty($_REQUEST['page'])&&$_SESSION["search"]=="yes")
					{
					  $_SESSION["search"]="yes";
					}
					else
					{
					   $_SESSION["search"]="no";
						unset($_SESSION["search"]);
						unset($_SESSION['field_name']);
						unset($_SESSION["field_value"]); 
					}
					include("buy_new_phone_list.php");
					break; 
        case "search_phone":
					$_REQUEST['page'] = 1;  
					$_SESSION["search"]="yes";
					$_SESSION['field_name'] = $_REQUEST['field_name'];
					$_SESSION["field_value"] = $_REQUEST['field_value'];
					include("buy_new_phone_editor.php");
					break;  
				
	     default :    
		         include("buy_new_phone_editor.php");		         
	   }

//Protect same image name
 function getMaxId($db)
 {
	   $info['table']    = "phone";
	   $info['fields']   = array("max(id) as maxid");   	   
	   $info['where']    =  "1=1";
	  
	   $resmax  =  $db->select($info);
	   if(count($resmax)>0)
	   {
		 $max = $resmax[0]['maxid']+1;
	   }
	   else
	   {
		$max=0;
	   }	  
	   return $max;
 } 	 
?>
