
STEPS:

1. Make database connection setting in config.php file
2. create database using phpmyadmin or whatever way you like
3. Import user.sql file into database.

Now you are ready to start register and login.
1. Enter the fields and click register
2. Now can you can login using the credential.

Passwords are encrypted by sha1 technique
For admin login
username:admin
Password:d033e22ae348aeb5660fc2140aec35850c4da997   

d033e22ae348aeb5660fc2140aec35850c4da997 is sha1() of admin

