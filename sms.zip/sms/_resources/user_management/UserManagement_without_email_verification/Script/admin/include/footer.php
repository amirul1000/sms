<footer id="footer">
	<ul class="nav pull-right">
		<li>
			Copyright &copy; ajay138
		</li>
	</ul>
</footer>