<style type="text/css">

    #loading-spinner {
        margin: -25px 0 0 -25px;
        width: 50px;
        height: 50px;
        position: absolute;
        left: 50%;
        top: 40%;
        z-index:99; /* makes sure it stays on top */
    }

    @-webkit-keyframes plus-top {
        2.5% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        13.75% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        13.76% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        25% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        27.5% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        41.25% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        41.26% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        63.75% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        63.76% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        75% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        77.5% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        91.25% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        91.26% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-moz-keyframes plus-top {
        2.5% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        13.75% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        13.76% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        25% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        27.5% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        41.25% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        41.26% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        63.75% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        63.76% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        75% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        77.5% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        91.25% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        91.26% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-o-keyframes plus-top {
        2.5% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        13.75% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        13.76% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        25% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        27.5% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        41.25% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        41.26% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        63.75% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        63.76% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        75% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        77.5% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        91.25% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        91.26% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @keyframes plus-top {
        2.5% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        13.75% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        13.76% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        25% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        27.5% {
            background: #ffcc66;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        41.25% {
            background: #ffae0d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        41.26% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        63.75% {
            background: #2cc642;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        63.76% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-out;
            -moz-animation-timing-function: ease-out;
            -ms-animation-timing-function: ease-out;
            -o-animation-timing-function: ease-out;
            animation-timing-function: ease-out;
        }

        75% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }

        77.5% {
            background: #44aaee;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        91.25% {
            background: #1386d2;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        91.26% {
            background: #ff430d;
            -webkit-transform: rotateY(90deg);
            -moz-transform: rotateY(90deg);
            -ms-transform: rotateY(90deg);
            -o-transform: rotateY(90deg);
            transform: rotateY(90deg);
            -webkit-animation-timing-function: ease-in;
            -moz-animation-timing-function: ease-in;
            -ms-animation-timing-function: ease-in;
            -o-animation-timing-function: ease-in;
            animation-timing-function: ease-in;
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateY(0deg);
            -moz-transform: rotateY(0deg);
            -ms-transform: rotateY(0deg);
            -o-transform: rotateY(0deg);
            transform: rotateY(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-webkit-keyframes plus-bottom {
        0% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        50% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        75% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        100% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-moz-keyframes plus-bottom {
        0% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        50% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        75% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        100% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-o-keyframes plus-bottom {
        0% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        50% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        75% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        100% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @keyframes plus-bottom {
        0% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        50% {
            background: #ffcc66;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        75% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        100% {
            background: #44aaee;
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-webkit-keyframes plus-background {
        0% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
        }

        25% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        27.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
        }

        75% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        77.5% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-moz-keyframes plus-background {
        0% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
        }

        25% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        27.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
        }

        75% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        77.5% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @-o-keyframes plus-background {
        0% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
        }

        25% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        27.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
        }

        75% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        77.5% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    @keyframes plus-background {
        0% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
        }

        25% {
            background: #ff8866;
            -webkit-transform: rotateZ(180deg);
            -moz-transform: rotateZ(180deg);
            -ms-transform: rotateZ(180deg);
            -o-transform: rotateZ(180deg);
            transform: rotateZ(180deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        27.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
        }

        50% {
            background: #66dd77;
            -webkit-transform: rotateZ(90deg);
            -moz-transform: rotateZ(90deg);
            -ms-transform: rotateZ(90deg);
            -o-transform: rotateZ(90deg);
            transform: rotateZ(90deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        52.5% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
        }

        75% {
            background: #66dd77;
            -webkit-transform: rotateZ(0deg);
            -moz-transform: rotateZ(0deg);
            -ms-transform: rotateZ(0deg);
            -o-transform: rotateZ(0deg);
            transform: rotateZ(0deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }

        77.5% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
        }

        100% {
            background: #ff8866;
            -webkit-transform: rotateZ(270deg);
            -moz-transform: rotateZ(270deg);
            -ms-transform: rotateZ(270deg);
            -o-transform: rotateZ(270deg);
            transform: rotateZ(270deg);
            -webkit-animation-timing-function: step-start;
            -moz-animation-timing-function: step-start;
            -ms-animation-timing-function: step-start;
            -o-animation-timing-function: step-start;
            animation-timing-function: step-start;
        }
    }

    /* Styles for old versions of IE */
    .plus {
        font-family: sans-serif;
        font-weight: 100;
    }

    /* :not(:required) hides this rule from IE9 and below */
    .plus:not(:required) {
        overflow: hidden;
        position: relative;
        text-indent: -9999px;
        display: inline-block;
        width: 48px;
        height: 48px;
        background: #ff8866;
        -webkit-border-radius: 24px;
        -moz-border-radius: 24px;
        -ms-border-radius: 24px;
        -o-border-radius: 24px;
        border-radius: 24px;
        -webkit-transform: rotateZ(90deg);
        -moz-transform: rotateZ(90deg);
        -ms-transform: rotateZ(90deg);
        -o-transform: rotateZ(90deg);
        transform: rotateZ(90deg);
        -webkit-transform-origin: 50% 50%;
        -moz-transform-origin: 50% 50%;
        -ms-transform-origin: 50% 50%;
        -o-transform-origin: 50% 50%;
        transform-origin: 50% 50%;
        -webkit-animation: plus-background 3s infinite ease-in-out;
        -moz-animation: plus-background 3s infinite ease-in-out;
        -ms-animation: plus-background 3s infinite ease-in-out;
        -o-animation: plus-background 3s infinite ease-in-out;
        animation: plus-background 3s infinite ease-in-out;
    }
    .plus:not(:required)::after {
        background: #ff8866;
        -webkit-border-radius: 24px 0 0 24px;
        -moz-border-radius: 24px 0 0 24px;
        -ms-border-radius: 24px 0 0 24px;
        -o-border-radius: 24px 0 0 24px;
        border-radius: 24px 0 0 24px;
        content: '';
        position: absolute;
        right: 50%;
        top: 0;
        width: 50%;
        height: 100%;
        -webkit-transform-origin: 100% 50%;
        -moz-transform-origin: 100% 50%;
        -ms-transform-origin: 100% 50%;
        -o-transform-origin: 100% 50%;
        transform-origin: 100% 50%;
        -webkit-animation: plus-top 3s infinite linear;
        -moz-animation: plus-top 3s infinite linear;
        -ms-animation: plus-top 3s infinite linear;
        -o-animation: plus-top 3s infinite linear;
        animation: plus-top 3s infinite linear;
    }
    .plus:not(:required)::before {
        background: #ffcc66;
        -webkit-border-radius: 24px 0 0 24px;
        -moz-border-radius: 24px 0 0 24px;
        -ms-border-radius: 24px 0 0 24px;
        -o-border-radius: 24px 0 0 24px;
        border-radius: 24px 0 0 24px;
        content: '';
        position: absolute;
        right: 50%;
        top: 0;
        width: 50%;
        height: 100%;
        -webkit-transform-origin: 100% 50%;
        -moz-transform-origin: 100% 50%;
        -ms-transform-origin: 100% 50%;
        -o-transform-origin: 100% 50%;
        transform-origin: 100% 50%;
        -webkit-animation: plus-bottom 3s infinite linear;
        -moz-animation: plus-bottom 3s infinite linear;
        -ms-animation: plus-bottom 3s infinite linear;
        -o-animation: plus-bottom 3s infinite linear;
        animation: plus-bottom 3s infinite linear;
    }
</style>
<!-- Preloader -->
<div id="loading-spinner">
    <div class="plus"></div>
</div>
<!-- /Preloader -->