-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 13, 2016 at 08:34 AM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastlogin_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `password`, `email`, `created_at`, `lastlogin_at`) VALUES
(1, 'Admin', 'admin', 'admin', 'admin@admin.com', '2014-11-25 11:57:28', '2016-06-03 01:42:32'),
(2, 'Admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin@admin.com', '2014-11-25 11:57:28', '2016-06-03 01:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `balance`
--

CREATE TABLE IF NOT EXISTS `balance` (
`id` int(10) NOT NULL,
  `users_id` int(10) NOT NULL,
  `txn_id` varchar(256) NOT NULL,
  `credit` decimal(10,4) NOT NULL,
  `debit` decimal(10,4) NOT NULL,
  `pay_by` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `balance`
--

INSERT INTO `balance` (`id`, `users_id`, `txn_id`, `credit`, `debit`, `pay_by`, `description`, `date_time`) VALUES
(6, 24, 'rerwr', 12.0000, 0.0000, '', '', '0000-00-00 00:00:00'),
(7, 24, '', 0.0000, 0.1000, 'deposit', '', '2016-06-12 00:00:00'),
(8, 24, '', 0.0000, 0.1000, 'deposit', '', '2016-06-12 00:00:00'),
(9, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00'),
(10, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00'),
(11, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00'),
(12, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00'),
(13, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00'),
(14, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00'),
(15, 24, '', 0.0000, 0.6000, 'deposit', '', '2016-06-12 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
`id` int(11) NOT NULL,
  `country` varchar(200) NOT NULL DEFAULT '',
  `status` enum('active','inactive') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `country`, `status`) VALUES
(1, 'Afghanistan', 'active'),
(2, 'Ã…land Islands', 'active'),
(3, 'Albania', 'active'),
(4, 'Algeria', 'active'),
(5, 'American Samoa', 'active'),
(6, 'Andorra', 'active'),
(7, 'Angola', 'active'),
(8, 'Anguilla', 'active'),
(9, 'Antarctica', 'active'),
(10, 'Antigua and Barbuda', 'active'),
(11, 'Argentina', 'active'),
(12, 'Armenia', 'active'),
(13, 'Aruba', 'active'),
(14, 'Australia', 'active'),
(15, 'Austria', 'active'),
(16, 'Azerbaijan', 'active'),
(17, 'Bahamas', 'active'),
(18, 'Bahrain', 'active'),
(19, 'Bangladesh', 'active'),
(20, 'Barbados', 'active'),
(21, 'Belarus', 'active'),
(22, 'Belgium', 'active'),
(23, 'Belize', 'active'),
(24, 'Benin', 'active'),
(25, 'Bermuda', 'active'),
(26, 'Bhutan', 'active'),
(27, 'Bolivia', 'active'),
(28, 'Bosnia and Herzegovina', 'active'),
(29, 'Botswana', 'active'),
(30, 'Bouvet Island', 'active'),
(31, 'Brazil', 'active'),
(32, 'British Indian Ocean Territory', 'active'),
(33, 'Brunei Darussalam', 'active'),
(34, 'Bulgaria', 'active'),
(35, 'Burkina Faso', 'active'),
(36, 'Burundi', 'active'),
(37, 'Cambodia', 'active'),
(38, 'Cameroon', 'active'),
(39, 'Canada', 'active'),
(40, 'Cape Verde', 'active'),
(41, 'Cayman Islands', 'active'),
(42, 'Central African Republic', 'active'),
(43, 'Chad', 'active'),
(44, 'Chile', 'active'),
(45, 'China', 'active'),
(46, 'Christmas Island', 'active'),
(47, 'Cocos (Keeling) Islands', 'active'),
(48, 'Colombia', 'active'),
(49, 'Comoros', 'active'),
(50, 'Congo', 'active'),
(51, 'Congo, The Democratic Republic of the', 'active'),
(52, 'Cook Islands', 'active'),
(53, 'Costa Rica', 'active'),
(54, 'CÃ´te D''Ivoire', 'active'),
(55, 'Croatia', 'active'),
(56, 'Cuba', 'active'),
(57, 'Cyprus', 'active'),
(58, 'Czech Republic', 'active'),
(59, 'Denmark', 'active'),
(60, 'Djibouti', 'active'),
(61, 'Dominica', 'active'),
(62, 'Dominican Republic', 'active'),
(63, 'Ecuador', 'active'),
(64, 'Egypt', 'active'),
(65, 'El Salvador', 'active'),
(66, 'Equatorial Guinea', 'active'),
(67, 'Eritrea', 'active'),
(68, 'Estonia', 'active'),
(69, 'Ethiopia', 'active'),
(70, 'Falkland Islands (Malvinas)', 'active'),
(71, 'Faroe Islands', 'active'),
(72, 'Fiji', 'active'),
(73, 'Finland', 'active'),
(74, 'France', 'active'),
(75, 'French Guiana', 'active'),
(76, 'French Polynesia', 'active'),
(77, 'French Southern Territories', 'active'),
(78, 'Gabon', 'active'),
(79, 'Gambia', 'active'),
(80, 'Georgia', 'active'),
(81, 'Germany', 'active'),
(82, 'Ghana', 'active'),
(83, 'Gibraltar', 'active'),
(84, 'Greece', 'active'),
(85, 'Greenland', 'active'),
(86, 'Grenada', 'active'),
(87, 'Guadeloupe', 'active'),
(88, 'Guam', 'active'),
(89, 'Guatemala', 'active'),
(90, 'Guernsey', 'active'),
(91, 'Guinea', 'active'),
(92, 'Guinea-Bissau', 'active'),
(93, 'Guyana', 'active'),
(94, 'Haiti', 'active'),
(95, 'Heard Island and McDonald Islands', 'active'),
(96, 'Holy See (Vatican City State)', 'active'),
(97, 'Honduras', 'active'),
(98, 'Hong Kong', 'active'),
(99, 'Hungary', 'active'),
(100, 'Iceland', 'active'),
(101, 'India', 'active'),
(102, 'Indonesia', 'active'),
(103, 'Iran, Islamic Republic of', 'active'),
(104, 'Iraq', 'active'),
(105, 'Ireland', 'active'),
(106, 'Isle of Man', 'active'),
(107, 'Israel', 'active'),
(108, 'Italy', 'active'),
(109, 'Jamaica', 'active'),
(110, 'Japan', 'active'),
(111, 'Jersey', 'active'),
(112, 'Jordan', 'active'),
(113, 'Kazakhstan', 'active'),
(114, 'Kenya', 'active'),
(115, 'Kiribati', 'active'),
(116, 'Korea, Democratic People''s Republic of', 'active'),
(117, 'Korea, Republic of', 'active'),
(118, 'Kuwait', 'active'),
(119, 'Kyrgyzstan', 'active'),
(120, 'Lao People''s Democratic Republic', 'active'),
(121, 'Latvia', 'active'),
(122, 'Lebanon', 'active'),
(123, 'Lesotho', 'active'),
(124, 'Liberia', 'active'),
(125, 'Libyan Arab Jamahiriya', 'active'),
(126, 'Liechtenstein', 'active'),
(127, 'Lithuania', 'active'),
(128, 'Luxembourg', 'active'),
(129, 'Macao', 'active'),
(130, 'Macedonia, The Former Yugoslav Republic of', 'active'),
(131, 'Madagascar', 'active'),
(132, 'Malawi', 'active'),
(133, 'Malaysia', 'active'),
(134, 'Maldives', 'active'),
(135, 'Mali', 'active'),
(136, 'Malta', 'active'),
(137, 'Marshall Islands', 'active'),
(138, 'Martinique', 'active'),
(139, 'Mauritania', 'active'),
(140, 'Mauritius', 'active'),
(141, 'Mayotte', 'active'),
(142, 'Mexico', 'active'),
(143, 'Micronesia, Federated States of', 'active'),
(144, 'Moldova, Republic of', 'active'),
(145, 'Monaco', 'active'),
(146, 'Mongolia', 'active'),
(147, 'Montenegro', 'active'),
(148, 'Montserrat', 'active'),
(149, 'Morocco', 'active'),
(150, 'Mozambique', 'active'),
(151, 'Myanmar', 'active'),
(152, 'Namibia', 'active'),
(153, 'Nauru', 'active'),
(154, 'Nepal', 'active'),
(155, 'Netherlands', 'active'),
(156, 'Netherlands Antilles', 'active'),
(157, 'New Caledonia', 'active'),
(158, 'New Zealand', 'active'),
(159, 'Nicaragua', 'active'),
(160, 'Niger', 'active'),
(161, 'Nigeria', 'active'),
(162, 'Niue', 'active'),
(163, 'Norfolk Island', 'active'),
(164, 'Northern Mariana Islands', 'active'),
(165, 'Norway', 'active'),
(166, 'Oman', 'active'),
(167, 'Pakistan', 'active'),
(168, 'Palau', 'active'),
(169, 'Palestinian Territory, Occupied', 'active'),
(170, 'Panama', 'active'),
(171, 'Papua New Guinea', 'active'),
(172, 'Paraguay', 'active'),
(173, 'Peru', 'active'),
(174, 'Philippines', 'active'),
(175, 'Pitcairn', 'active'),
(176, 'Poland', 'active'),
(177, 'Portugal', 'active'),
(178, 'Puerto Rico', 'active'),
(179, 'Qatar', 'active'),
(180, 'Reunion', 'active'),
(181, 'Romania', 'active'),
(182, 'Russian Federation', 'active'),
(183, 'Rwanda', 'active'),
(184, 'Saint BarthÃ©lemy', 'active'),
(185, 'Saint Helena', 'active'),
(186, 'Saint Kitts and Nevis', 'active'),
(187, 'Saint Lucia', 'active'),
(188, 'Saint Martin', 'active'),
(189, 'Saint Pierre and Miquelon', 'active'),
(190, 'Saint Vincent and the Grenadines', 'active'),
(191, 'Samoa', 'active'),
(192, 'San Marino', 'active'),
(193, 'Sao Tome and Principe', 'active'),
(194, 'Saudi Arabia', 'active'),
(195, 'Senegal', 'active'),
(196, 'Serbia', 'active'),
(197, 'Seychelles', 'active'),
(198, 'Sierra Leone', 'active'),
(199, 'Singapore', 'active'),
(200, 'Slovakia', 'active'),
(201, 'Slovenia', 'active'),
(202, 'Solomon Islands', 'active'),
(203, 'Somalia', 'active'),
(204, 'South Africa', 'active'),
(205, 'South Georgia and the South Sandwich Islands', 'active'),
(206, 'Spain', 'active'),
(207, 'Sri Lanka', 'active'),
(208, 'Sudan', 'active'),
(209, 'Suriname', 'active'),
(210, 'Svalbard and Jan Mayen', 'active'),
(211, 'Swaziland', 'active'),
(212, 'Sweden', 'active'),
(213, 'Switzerland', 'active'),
(214, 'Syrian Arab Republic', 'active'),
(215, 'Taiwan, Province Of China', 'active'),
(216, 'Tajikistan', 'active'),
(217, 'Tanzania, United Republic of', 'active'),
(218, 'Thailand', 'active'),
(219, 'Timor-Leste', 'active'),
(220, 'Togo', 'active'),
(221, 'Tokelau', 'active'),
(222, 'Tonga', 'active'),
(223, 'Trinidad and Tobago', 'active'),
(224, 'Tunisia', 'active'),
(225, 'Turkey', 'active'),
(226, 'Turkmenistan', 'active'),
(227, 'Turks and Caicos Islands', 'active'),
(228, 'Tuvalu', 'active'),
(229, 'Uganda', 'active'),
(230, 'Ukraine', 'active'),
(231, 'United Arab Emirates', 'active'),
(232, 'United Kingdom', 'active'),
(233, 'United States', 'active'),
(234, 'United States Minor Outlying Islands', 'active'),
(235, 'Uruguay', 'active'),
(236, 'Uzbekistan', 'active'),
(237, 'Vanuatu', 'active'),
(238, 'Venezuela', 'active'),
(239, 'Viet Nam', 'active'),
(240, 'Virgin Islands, British', 'active'),
(241, 'Virgin Islands, U.S.', 'active'),
(242, 'Wallis And Futuna', 'active'),
(243, 'Western Sahara', 'active'),
(244, 'Yemen', 'active'),
(245, 'Zambia', 'active'),
(246, 'Zimbabwe', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE IF NOT EXISTS `phone` (
`id` int(10) NOT NULL,
  `country_id` int(10) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `sale_price` decimal(10,4) NOT NULL,
  `booked_till_date` datetime NOT NULL,
  `status` enum('free','booked') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phone`
--

INSERT INTO `phone` (`id`, `country_id`, `phone_no`, `sale_price`, `booked_till_date`, `status`) VALUES
(1, 233, '+142434343344', 0.0000, '2016-07-12 00:00:00', 'booked'),
(2, 233, '+142434343341', 0.0000, '0000-00-00 00:00:00', ''),
(3, 233, '+142434343341', 0.0000, '0000-00-00 00:00:00', ''),
(4, 233, '+142434344341', 0.0000, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `phonesold`
--

CREATE TABLE IF NOT EXISTS `phonesold` (
`id` int(10) NOT NULL,
  `users_id` int(10) NOT NULL,
  `phone_id` int(10) NOT NULL,
  `buy_price` decimal(10,4) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `status` enum('active','inactive') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phonesold`
--

INSERT INTO `phonesold` (`id`, `users_id`, `phone_id`, `buy_price`, `start_date`, `end_date`, `status`) VALUES
(9, 24, 1, 0.6000, '2016-06-12 08:21:43', '2016-07-12 00:00:00', 'active'),
(10, 24, 1, 0.6000, '2016-06-12 08:23:12', '2016-07-12 00:00:00', 'active'),
(11, 24, 2, 0.6000, '2016-06-12 08:24:21', '2016-07-12 00:00:00', 'active'),
(12, 24, 1, 0.6000, '2016-06-12 08:25:33', '2016-07-12 00:00:00', 'active'),
(13, 24, 1, 0.6000, '2016-06-12 08:26:42', '2016-07-12 00:00:00', 'active'),
(14, 24, 1, 0.6000, '2016-06-12 08:50:32', '2016-07-12 00:00:00', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `receivesms`
--

CREATE TABLE IF NOT EXISTS `receivesms` (
`id` int(10) NOT NULL,
  `users_id` int(10) NOT NULL,
  `BODY` varchar(128) NOT NULL,
  `MONUMBER` varchar(64) NOT NULL,
  `DESTINATION` varchar(64) NOT NULL,
  `RECEIVETIME` varchar(64) NOT NULL,
  `GUID` varchar(128) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receivesms`
--

INSERT INTO `receivesms` (`id`, `users_id`, `BODY`, `MONUMBER`, `DESTINATION`, `RECEIVETIME`, `GUID`, `date_time`) VALUES
(1, 24, '4434', '3434', '34343', '434343', '434', '2016-06-12 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) unsigned NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `avatar` varchar(30) DEFAULT 'noimage.gif',
  `address` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `user_type` enum('admin','customer') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `avatar`, `address`, `created_at`, `status`, `user_type`) VALUES
(24, 'AA', 'BB', 'xx', 'xx', 'noimage.gif', 'aa', '2016-06-02 08:58:56', 'disable', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `balance`
--
ALTER TABLE `balance`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phone`
--
ALTER TABLE `phone`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phonesold`
--
ALTER TABLE `phonesold`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receivesms`
--
ALTER TABLE `receivesms`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `balance`
--
ALTER TABLE `balance`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=247;
--
-- AUTO_INCREMENT for table `phone`
--
ALTER TABLE `phone`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `phonesold`
--
ALTER TABLE `phonesold`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `receivesms`
--
ALTER TABLE `receivesms`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
